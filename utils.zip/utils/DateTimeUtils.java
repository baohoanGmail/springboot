
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;

public class DateTimeUtils {

  public static final String LOCAL_DATE_FORMAT = "yyyy-MM-dd";

  public static final String SIMPLE_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

  public static final String PERIOD_DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm";

  public static final String DATE_TIME_FORMAT_WITH_T = "yyyy-MM-dd'T'HH:mm:ss";

  public static final String DATE_WEB_FORMAT = "yyyy-MM-dd 00:00";

  private DateTimeUtils() {}

  /**
   * Get current date with format using for CSV filename
   * 
   * @return
   */
  public static String getDateWithBasicFormat() {

    return LocalDateTime.now().format(DateTimeFormatter.BASIC_ISO_DATE);
  }

  /**
   * get current date time
   * 
   * @return LocalDateTime
   */
  public static LocalDateTime current() {
    return LocalDateTime.now();
  }

  /**
   * Convert String to LocalDate
   * 
   * @param value
   * @return
   */
  public static LocalDate convertStringToLocalDate(String value) {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(LOCAL_DATE_FORMAT);
    return LocalDate.parse(value, formatter);
  }


  /**
   * Get the start moment of current date
   * 
   * @return LocalDateTime
   */

  public static LocalDateTime getStartOfCurrentDate() {
    return LocalDateTime.now().withHour(0).withMinute(0).withSecond(0);
  }

  /**
   * Get the end moment of current date
   * 
   * @return LocalDateTime
   */
  public static LocalDateTime getEndOfCurrentDate() {
    return LocalDateTime.now().withHour(23).withMinute(59).withSecond(59);
  }

  /**
   * Get the start moment of input date
   * 
   * @param date input a LocalDate
   * @return LocalDateTime
   */
  public static LocalDateTime getStartOfDate(LocalDate date) {
    return date.atStartOfDay();
  }

  /**
   * Get the end moment of input date
   * 
   * @param date input a LocalDate
   * @return LocalDateTime
   */
  public static LocalDateTime getEndOfDate(LocalDate date) {
    return date.atTime(23, 59, 59);
  }


  /**
   * Parse current date to string following the format yyyy-MM-dd HH:mm:ss
   * 
   * @return LocalDateTime
   */
  public static String getCurrentDateTimeAsString() {
    return current().format(DateTimeFormatter.ofPattern(SIMPLE_DATE_FORMAT));
  }

  /**
   * Get last date of 6 months ago.
   * 
   * @return LocalDateTime
   */
  public static LocalDateTime getLastDateOf6MonthsAgo() {
    LocalDateTime last6MonthsDate = LocalDateTime.now().minusMonths(6);
    YearMonth last6Months = YearMonth.now().minusMonths(6);
    return last6MonthsDate.withDayOfMonth(last6Months.lengthOfMonth()).withHour(23).withMinute(59)
        .withSecond(59);
  }

  /**
   * Get last date of 6 months ago and parse to String
   * 
   * @return String
   */
  public static String getLastDateOf6MonthsAgoAsString() {
    return getLastDateOf6MonthsAgo().format(DateTimeFormatter.ofPattern(SIMPLE_DATE_FORMAT));
  }

  /**
   * Get last date of month
   * 
   * @return LocalDateTime
   */
  public static LocalDateTime getLastDateOfMonth() {
    LocalDate date = LocalDate.now();
    return LocalDateTime.now().withDayOfMonth(date.lengthOfMonth()).withHour(23).withMinute(59)
        .withSecond(59);
  }

  /**
   * Get last date of month and parse to String
   * 
   * @return String
   */
  public static String getLastDateOfMonthAsString() {
    return getLastDateOfMonth().format(DateTimeFormatter.ofPattern(SIMPLE_DATE_FORMAT));
  }

  /**
   * Get first date of month
   * 
   * @return LocalDate
   */
  public static LocalDate getFirstDateOfMonth() {
    LocalDate date = LocalDate.now();
    return date.withDayOfMonth(1);
  }

  /**
   * Check input date can parse to date with format yyyy-MM-dd HH:mm
   * 
   * @param dateTime String needs to verify
   * 
   * @return true if input string can be converted to yyyy-MM-dd HH:mm
   */
  public static boolean isValidWithFormat(String dateTime, String format) {

    if (dateTime == null) {
      return false;
    }
    try {
      LocalDateTime.parse(dateTime, DateTimeFormatter.ofPattern(format));
      return true;
    } catch (DateTimeException e) {
      return false;
    }
  }

  /**
   * Converting a String to date time with input format
   * 
   * @param value input string
   * @param format input format
   * @return
   */
  public static LocalDateTime format(String value, String format) {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
    return LocalDateTime.parse(value, formatter);
  }

  /**
   * 
   * @param date
   * @param format
   * @return
   */
  public static String format(LocalDateTime date, String format) {
    return date.format(DateTimeFormatter.ofPattern(format));
  }

  /**
   * Convert String to LocalDate
   * 
   * @param value
   * @return
   */
  public static boolean isValidDate(String value) {
    try {
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern(LOCAL_DATE_FORMAT);
      LocalDate.parse(value, formatter);
      return true;
    } catch (Exception e) {
      return false;
    }
  }

  /**
   * Convert LocalDateTime to String
   * 
   * @param value
   * @return
   */
  public static String convertLocalDateTimeToString(LocalDateTime value) {
    return value.format(DateTimeFormatter.ofPattern(PERIOD_DATE_TIME_FORMAT));
  }

  /**
   * Convert String to LocalDateTime
   * 
   * @param value
   * @return
   */
  public static LocalDateTime convertStringToLocalDateTime(String value) {

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(PERIOD_DATE_TIME_FORMAT);
    return LocalDateTime.parse(value, formatter);
  }
}
