
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This is to define all singleton objects.
 */
public final class JsonUtils {

  private static final ObjectMapper objectMapper;

  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(JsonUtils.class);

  static {
    objectMapper = new ObjectMapper();
    objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    objectMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
    objectMapper.setSerializationInclusion(Include.NON_NULL);
  }

  /**
   * Prevents developer from initiating instance.
   */
  private JsonUtils() {

  }

  /**
   * Gets the object mapper.
   *
   * @return the objectMapper
   */
  public static ObjectMapper getObjectMapper() {
    return objectMapper;
  }

  /**
   * Write a object to string
   * 
   * @param object
   * @return the string of object
   */
  public static String object2Json(Object object) {
    try {
      return objectMapper.writeValueAsString(object);
    } catch (JsonProcessingException e) {
      LOGGER.error("[object2JsonString]: {}", e.getMessage());
      return StringUtils.EMPTY;
    }
  }

  /**
   * Converts a Json string to Object
   * 
   * @param jsonData the Json string
   * @param returnType the java type
   * @return a converted object.
   */
  public static <T> Optional<T> json2Object(String jsonData, Class<T> returnType) {
    try {

      if (StringUtils.isBlank(jsonData)) {
        return Optional.empty();
      }
      return Optional.ofNullable(objectMapper.readValue(jsonData, returnType));
    } catch (Exception e) {
      LOGGER.error("[json2Object] {}", e);
      return Optional.empty();
    }
  }
  
  public static <T> Optional<T[]> json2Array(String jsonString, Class<T[]> classes) {
	  
	if (StringUtils.isBlank(jsonString)) {
	  return Optional.empty();
	}

	try {
	  return Optional.ofNullable(objectMapper.readValue(jsonString, classes));
	} catch (Exception e) {
	  LOGGER.error("Parse json to list failed: {}", e.getLocalizedMessage());
	  return Optional.empty();
	}
  }
}
