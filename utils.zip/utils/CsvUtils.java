
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.lang.reflect.Field;
import java.nio.charset.Charset;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import lombok.extern.log4j.Log4j2;
import uk.gov.nationalarchives.csv.validator.api.java.CsvValidator;
import uk.gov.nationalarchives.csv.validator.api.java.FailMessage;
import uk.gov.nationalarchives.csv.validator.api.java.WarningMessage;

@Log4j2
public class CsvUtils {

  private static final String HEADERS = "headers";
  private static final String FIELD_NAMES = "fieldnames";
  // CSV format with new line code CRLF
  private static final CSVFormat CSV_FORMAT = CSVFormat.DEFAULT.withSystemRecordSeparator();

  private CsvUtils() {}

  /**
   * Find the field in Object by field name.
   * 
   * @param fieldName the name of field
   * @param clazz the generic object
   * @param level If the function calls itself more than {level} times, the function will be
   *        stopped.
   * @return the field
   */
  private static Optional<Field> getFieldByName(String fieldName, Class<?> clazz, int level) {

    if (clazz == null || level < 1) {
      return Optional.empty();
    }

    try {
      return Optional.ofNullable(clazz.getDeclaredField(fieldName));
    } catch (NoSuchFieldException | SecurityException e) {
      return getFieldByName(fieldName, clazz.getSuperclass(), --level);
    }
  }

  /**
   * Returns the value of the field represented by this Field, on the specified object. <br/>
   * The value is automatically wrapped in an object if it has a primitive type.
   * 
   * @param field the {@link Field}
   * @param data the object from which the represented field's value is to be extracted
   * @return the value of the represented field by object
   */
  private static <T> String getValueFromField(Field field, T data) {

    if (field == null) {
      return StringUtils.EMPTY;
    }

    try {
      field.setAccessible(true);
      Object valueOfField = field.get(data);

      if (valueOfField == null) {
        return StringUtils.EMPTY;
      }

      if (field.getType() == LocalDateTime.class) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(Const.DATE_TIME_FORMATTER);
        return ((LocalDateTime) valueOfField).format(formatter);
      }
      return String.valueOf(valueOfField);
    } catch (IllegalArgumentException | IllegalAccessException e) {
      log.error("Can not get value from field {}", e.getLocalizedMessage());
      return StringUtils.EMPTY;
    }
  }

  private static <T> String[] getRowValueByFieldNames(T dataRow, String[] fieldnames) {

    List<String> values = new ArrayList<>();

    Stream.of(fieldnames).forEach(fieldname -> {
      Optional<Field> field = getFieldByName(fieldname, dataRow.getClass(), 3);

      if (field.isPresent()) {
        values.add(getValueFromField(field.get(), dataRow));
      } else {
        values.add(StringUtils.EMPTY);
      }
    });
    return values.toArray(new String[values.size()]);
  }

  /**
   * Handle export CSV <br/>
   * 
   * headers is an array string header show on CSV file. <br/>
   * fieldNames is an array string that extracts field names from object properties.
   * 
   * @param data a list of rows
   * @return Optional<ByteArrayOutputStream>
   * @throws IOException
   */
  public static <T> Optional<ByteArrayOutputStream> export(String[] headers, String[] fieldnames,
      List<T> data) throws IOException {

    try (ByteArrayOutputStream out = new ByteArrayOutputStream();
        BufferedWriter writer =
            new BufferedWriter(new OutputStreamWriter(out, Charset.forName("SHIFT-JIS")));
        CSVPrinter csvPrinter = new CSVPrinter(writer, CSV_FORMAT.withHeader(headers));) {

      if (CollectionUtils.isNotEmpty(data)) {
        List<String[]> content = new ArrayList<>();
        data.forEach(row -> content.add(getRowValueByFieldNames(row, fieldnames)));

        for (String[] c : content) {
          csvPrinter.printRecord(Arrays.asList(c));
        }
      }

      csvPrinter.flush();
      return Optional.ofNullable(out);
    }
  }

  /**
   * Handle export CSV
   * 
   * @param csvInfoMap includes two keys headers and fieldnames. <br/>
   *        headers is an array string header show on CSV file. <br/>
   *        fieldNames is an array string that extracts field names from object properties.
   * @param data a list of rows
   * @return Optional<ByteArrayOutputStream>
   * @throws IOException
   */
  private static final Map<String, String[]> extractCsvInfoFromMap(Map<String, String> csvInfoMap) {

    Map<String, String[]> csvInfo = new HashMap<>();
    if (csvInfoMap == null || csvInfoMap.isEmpty()) {

      log.info("CSV cannot extract headers and fieldname, No data map input");
      csvInfo.put(HEADERS, ArrayUtils.EMPTY_STRING_ARRAY);
      csvInfo.put(FIELD_NAMES, ArrayUtils.EMPTY_STRING_ARRAY);

      return csvInfo;
    }

    List<String> headers = new LinkedList<>();
    List<String> fieldnames = new LinkedList<>();

    csvInfoMap.forEach((fieldname, header) -> {
      fieldnames.add(fieldname);
      headers.add(header);
    });

    csvInfo.put(HEADERS, headers.toArray(new String[headers.size()]));
    csvInfo.put(FIELD_NAMES, fieldnames.toArray(new String[fieldnames.size()]));

    return csvInfo;
  }

  /**
   * Handle export CSV
   * 
   * @param csvMapConst a {@link Map}
   * @param data a list of rows
   * @return Optional<ByteArrayOutputStream>
   * @throws IOException
   */
  public static <T> Optional<ByteArrayOutputStream> export(Map<String, String> csvMapConst,
      List<T> data) throws IOException {

    Map<String, String[]> csvInfo = extractCsvInfoFromMap(csvMapConst);
    String[] headers = csvInfo.get(HEADERS);
    String[] fieldnames = csvInfo.get(FIELD_NAMES);

    try (ByteArrayOutputStream out = new ByteArrayOutputStream();
        BufferedWriter writer =
            new BufferedWriter(new OutputStreamWriter(out, Charset.forName("SHIFT-JIS")));
        CSVPrinter csvPrinter = new CSVPrinter(writer, CSV_FORMAT.withHeader(headers));) {

      if (CollectionUtils.isNotEmpty(data)) {
        List<String[]> content = new ArrayList<>();
        data.forEach(row -> content.add(getRowValueByFieldNames(row, fieldnames)));

        for (String[] c : content) {
          csvPrinter.printRecord(Arrays.asList(c));
        }
      }

      csvPrinter.flush();
      return Optional.ofNullable(out);
    }
  }

  /**
   * Build common header for exporting CSV
   * 
   * @param response
   */
  public static void buildResponseHeader(HttpServletResponse response, String filename) {

    String csvFileName = StringUtils.defaultIfBlank(filename, "report");
    String localDate = DateTimeUtils.getDateWithBasicFormat();

    StringBuilder fileNameBuilder = new StringBuilder("attachment; filename=");
    fileNameBuilder.append(localDate + "_");
    fileNameBuilder.append(csvFileName);

    if (csvFileName.indexOf(".csv") < 0) {
      fileNameBuilder.append(".csv");
    }

    response.setContentType(Const.TEXT_CSV_SHIFT_JIS);
    response.setCharacterEncoding("Shift_JIS");
    response.setHeader(HttpHeaders.CONTENT_DISPOSITION, fileNameBuilder.toString());
  }

  public static boolean validateCSVFormat(Reader csvPath, Reader csvSchemaPath) {

    List<FailMessage> messages =
        CsvValidator.validate(csvPath, csvSchemaPath, true, new ArrayList<>(), true);

    if (messages.isEmpty()) {
      log.info("CSV validation is completed!!!");
      return true;
    } else {
      for (FailMessage message : messages) {
        if (message instanceof WarningMessage) {
          log.info("[WARN] {}", message.getMessage());
        } else {
          log.error("[ERROR] {}", message.getMessage());
        }
      }
    }
    return false;
  }
}
