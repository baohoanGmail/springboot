
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import com.smcc.back.common.utils.MessageUtils;

@Component
public class StaticContextInitializer {

  @Autowired
  private MessageSource messageSource;

  @PostConstruct
  public void init() {
    MessageUtils.setMessageSource(messageSource);
  }
}
