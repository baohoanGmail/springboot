
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.multipart.MultipartFile;

public class FileUtils {

  private FileUtils() {}

  /**
   * @throws IOException
   * 
   */
  public static void saveFile(MultipartFile file, String imagePath, String fileName)
      throws IOException {

    byte[] bytes;
    bytes = file.getBytes();

    Path path = Paths.get(imagePath + fileName);
    Files.write(path, bytes);
  }

  public static void deleteFile(String imagePath, String fileName) throws IOException {

    Path path = Paths.get(imagePath + fileName);
    Files.deleteIfExists(path);
  }

  public static String getExtension(String filename) {
    return Optional.ofNullable(filename).filter(f -> f.contains("."))
        .map(f -> f.substring(filename.lastIndexOf('.') + 1)).orElse(StringUtils.EMPTY);
  }
}
