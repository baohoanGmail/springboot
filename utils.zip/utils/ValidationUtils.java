
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class ValidationUtils {

  private static final Logger LOGGER = LoggerFactory.getLogger(ValidationUtils.class);

  private static final String VALID_ONLY_NUMBER_REGEX = "[^０-９0-9]";

  private static final String VALID_ONLY_TEXT_REGEX = "^([^0-9]*)$";

  private static final String VALID_KATAKANA_NAME_REGEX = "^[ぁ-んァ-ヶー]*$";
  
  private static final String VALID_ROMAJI_NAME_REGEX = "^[a-zA-Z0-9]*$";
  
  private static final String VALID_EMAIL_REGEX = "(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])";

  private static Pattern[] patterns = new Pattern[] {
      // Script fragments
      Pattern.compile("<script>(.*?)</script>", Pattern.CASE_INSENSITIVE),
      // src='...'
      Pattern.compile("src[\r\n]*=[\r\n]*\\\'(.*?)\\\'", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
      Pattern.compile("src[\r\n]*=[\r\n]*\\\"(.*?)\\\"", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
      // lonely script tags
      Pattern.compile("</script>", Pattern.CASE_INSENSITIVE),
      Pattern.compile("<script(.*?)>", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
      // eval(...)
      Pattern.compile("eval\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
      // expression(...)
      Pattern.compile("expression\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
      // javascript:...
      Pattern.compile("javascript:", Pattern.CASE_INSENSITIVE),
      // vbscript:...
      Pattern.compile("vbscript:", Pattern.CASE_INSENSITIVE),
      // onload(...)=...
      Pattern.compile("onload(.*?)=", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL)
  };
  
  private static ValidationUtils instance = null;

  private ValidationUtils() {}


  private boolean validateByRegex(String content, String regex) {
    if (StringUtils.isBlank(content)) {
      return false;
    }
    Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
    Matcher matcher = pattern.matcher(content);
    return matcher.find();
  }

  private List<Field> getDeclarationFields(Object obj) {
    List<Field> fields = new ArrayList<>();
    Class<?> clazz = obj.getClass();
    fields.addAll(Arrays.asList(clazz.getDeclaredFields()));
    while (clazz.getSuperclass() != null) {
      clazz = clazz.getSuperclass();
      fields.addAll(Arrays.asList(clazz.getDeclaredFields()));
    }
    return fields;
  }

  public Set<ErrorValidation> validate(Object objectToValidate) {
    Set<ErrorValidation> errors = new HashSet<>();
    if (objectToValidate == null) {
      errors.add(new ErrorValidation("objectToValidate", "", "object to validate is empty!"));
      return errors;
    }

    List<Field> declaredFields = getDeclarationFields(objectToValidate);
    Optional<ErrorValidation> oValidateResult = null;
    for (Field field : declaredFields) {
      oValidateResult = Optional.ofNullable(validateForNull(field, objectToValidate));
      if (oValidateResult.isPresent()) {
        errors.add(oValidateResult.get());
        continue;
      }
      
      oValidateResult = Optional.ofNullable(validateXSS(field, objectToValidate));
      if (oValidateResult.isPresent()) {
        errors.add(oValidateResult.get());
        continue;
      }
      
      oValidateResult = Optional.ofNullable(validateForEmail(field, objectToValidate));
      if (oValidateResult.isPresent()) {
        errors.add(oValidateResult.get());
        continue;
      }
      oValidateResult = Optional.ofNullable(validateForPostCode(field, objectToValidate));
      if (oValidateResult.isPresent()) {
        errors.add(oValidateResult.get());
        continue;
      }
      oValidateResult = Optional.ofNullable(validateForPhoneNumber(field, objectToValidate));
      if (oValidateResult.isPresent()) {
        errors.add(oValidateResult.get());
      }
    }
    return errors;
  }

  private <T extends Annotation> boolean isValidField(Field field, Class<T> annotationClass) {
    if (Objects.isNull(field)) {
      return false;
    }
    return Optional.ofNullable(field.getAnnotation(annotationClass)).isPresent();
  }

  private String getValueFromField(Field field, Object objectToValidate) {
    try {
      field.setAccessible(true);
      return (String) field.get(objectToValidate);
    } catch (IllegalArgumentException | IllegalAccessException e) {
      LOGGER.error(e.getMessage());
      return StringUtils.EMPTY;
    }
  }

  /**
   * This function is used to validate an element marked as @Required </br>
   * 1. Validate the value length must be limited to minimum and maximum lengths </br>
   * 2. Validate the value only contain text </br>
   * 3. Validate the value is KATAKANA name </br>
   * 
   * @param field The field is defined in objectToValidate
   * @param objectToValidate The objectToValidate needs to be validated
   * @return The errors if this is an invalid object
   * @throws IllegalAccessException
   * 
   * 
   */

  public ErrorValidation validateForNull(Field field, Object objectToValidate) {
    if (!isValidField(field, Required.class)) {
      return null;
    }
    Required required = field.getAnnotation(Required.class);
    String value = getValueFromField(field, objectToValidate);
    if (required.notNull() && StringUtils.isBlank(value)) {
      return new ErrorValidation(field.getName(), value, required.requiredMessage());
    }
    
    String valueEsc = value;
    if (isScript(value)) {
      valueEsc = escapeScript(valueEsc);
    }
    
    if (required.maxLength() > 0 && (StringUtils.length(value) > required.maxLength())) {
      return new ErrorValidation(field.getName(), valueEsc, required.exceedsLimitMessage());
    }
    if (required.textOnly() && !validateByRegex(value, VALID_ONLY_TEXT_REGEX)) {
      return new ErrorValidation(field.getName(), valueEsc, required.message());
    }
    if (required.isKatakana() && !validateByRegex(value, VALID_KATAKANA_NAME_REGEX)) {
      return new ErrorValidation(field.getName(), valueEsc, required.message());
    }
    if (required.isRomaji() && !validateByRegex(value, VALID_ROMAJI_NAME_REGEX)) {
      return new ErrorValidation(field.getName(), valueEsc, required.message());
    }
    return null;
  }

  /**
   * Get email by key from the object need to validate.</br>
   * the function find all element that is @Email and keyPairs equals input key and confirmed is
   * false.
   * 
   * @param key
   * @return email
   * @throws IllegalAccessException
   * 
   */

  private String extractEmailByKey(int key, Object objectToValidate) {
    if (objectToValidate == null) {
      LOGGER.info("[extractEmailByKey] objectToValidate is nullable");
      return StringUtils.EMPTY;
    }
    List<Field> fields = getDeclarationFields(objectToValidate);
    Optional<Field> oField =
        fields.stream()
            .filter(p -> isValidField(p, Email.class)
                && (p.getAnnotation(Email.class).keyPairs() == key)
                && (!p.getAnnotation(Email.class).confirmed()))
            .findFirst();

    if (oField.isPresent()) {
      String emailExtract = getValueFromField(oField.get(), objectToValidate);
      LOGGER.debug("[extractEmailByKey]: {}", emailExtract);
      return emailExtract;
    }
    return StringUtils.EMPTY;
  }

  /**
   * This function is used to validate an element marked as @Email </br>
   * 1. Validate the email format (e.g. email must contains @) </br>
   * 2. Validate that this email matches another email with the same keyPairs </br>
   * 
   * @param field The field is defined in objectToValidate
   * @param objectToValidate The objectToValidate needs to be validated
   * @return The errors if this is an invalid object
   * @throws IllegalAccessException
   * 
   */

  public ErrorValidation validateForEmail(Field field, Object objectToValidate) {
    if (!isValidField(field, Email.class)) {
      return null;
    }
    Email email = field.getAnnotation(Email.class);
    String value = getValueFromField(field, objectToValidate);
    if (!validateByRegex(value, email.pattern())) {
      return new ErrorValidation(field.getName(), value, email.message());
    }
    if (email.confirmed()
        && !StringUtils.equals(value, extractEmailByKey(email.keyPairs(), objectToValidate))) {
      return new ErrorValidation(field.getName(), value, email.notMatchMessage());
    }
    return null;
  }

  /**
   * This function is used to validate an element marked as @PostCode </br>
   * 1. Validate the post code format (e.g. only number) </br>
   * 2. Validate the length value in lengthRequired </br>
   * 
   * @param field The field is defined in objectToValidate
   * @param objectToValidate The objectToValidate needs to be validated
   * @return The errors if this is an invalid object
   * @throws IllegalAccessException
   * 
   */

  public ErrorValidation validateForPostCode(Field field, Object objectToValidate) {
    if (!isValidField(field, PostCode.class)) {
      return null;
    }
    PostCode postcode = field.getAnnotation(PostCode.class);
    String value = StringUtils.trimToEmpty(getValueFromField(field, objectToValidate))
        .replaceAll(VALID_ONLY_NUMBER_REGEX, StringUtils.EMPTY);
    if (value.length() != postcode.lengthRequired()) {
      return new ErrorValidation(field.getName(), value, postcode.message());
    }
    if (!validateByRegex(value, postcode.pattern())) {
      return new ErrorValidation(field.getName(), value, postcode.message());
    }
    return null;
  }

  /**
   * This function is used to validate an element marked as @Phone </br>
   * 1. Validate the phone number format (e.g. only number) </br>
   * 2. Validate the length value must be limited to minimum and maximum lengths </br>
   * 
   * @param field The field is defined in objectToValidate
   * @param objectToValidate The objectToValidate needs to be validated
   * @return The errors if this is an invalid object
   * @throws IllegalAccessException
   * 
   */
  public ErrorValidation validateForPhoneNumber(Field field, Object objectToValidate) {
    if (!isValidField(field, Phone.class)) {
      return null;
    }
    Phone phone = field.getAnnotation(Phone.class);
    String value = getValueFromField(field, objectToValidate);
    int length = StringUtils.trimToEmpty(value).length();
    if (length < phone.minLength() || length > phone.maxLength()) {
      return new ErrorValidation(field.getName(), value, phone.message());
    }
    if (!validateByRegex(value, phone.pattern())) {
      return new ErrorValidation(field.getName(), value, phone.message());
    }
    return null;
  }
  
  /**
   * This function is used to validate an element marked as @Phone </br>
   * 1. Validate the phone number format (e.g. only number) </br>
   * 2. Validate the length value must be limited to minimum and maximum lengths </br>
   * 
   * @param field The field is defined in objectToValidate
   * @param objectToValidate The objectToValidate needs to be validated
   * @return The errors if this is an invalid object
   * @throws IllegalAccessException
   * 
   */
  public ErrorValidation validateXSS(Field field, Object objectToValidate) {
    if (!isValidField(field, XSS.class)) {
      return null;
    }
    XSS xss = field.getAnnotation(XSS.class);
    String value = getValueFromField(field, objectToValidate);
    
    if (isScript(value)) {
      return new ErrorValidation(field.getName(), escapeScript(value), xss.message());
    }
    return null;
  }

  /**
   * @return the ValidationUtils instance
   */
  public static ValidationUtils getInstance() {
    if (instance == null) {
      instance = new ValidationUtils();
    }
    return instance;
  }

  /**
   * @return the boolean is true if errors is not empty.
   */
  public boolean hasError(Set<ErrorValidation> errors) {
    return (errors != null) && !errors.isEmpty();
  }
  
  public boolean isValidEmail(String email) {
    return validateByRegex(email, VALID_EMAIL_REGEX);
  }
  
  public static boolean isScript(String value) {
    if (value != null) {
      for (Pattern scriptPattern : patterns) {
        if (scriptPattern.matcher(value).find()) {
          return true;
        }
      }
    }
    return false;
  }
  
  private static String escapeScript(String value) {
    if (StringUtils.isEmpty(value)) {
      return value;
    }
    return value.replaceAll("(?i)<(/?script[^>]*)>", "&lt;$1&gt;");
  }
}
