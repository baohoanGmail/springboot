package com.smcc.back.common.utils;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.MessageSource;

public class MessageUtils {

  private MessageUtils() {}

  private static MessageSource messageSource;

  public static void setMessageSource(MessageSource source) {
    messageSource = source;
  }

  public static final String get(String code) {

    if (messageSource == null) {
      return StringUtils.EMPTY;
    }
    return messageSource.getMessage(code.replaceAll("\\{|\\}", ""), null, null);
  }

}
