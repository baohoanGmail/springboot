
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.stream.Stream;

public class EntityUtils {

  private EntityUtils() {}

  /**
   * Find the field in Object by field name.
   * 
   * @param fieldName the name of field
   * @param clazz the generic object
   * @param level If the function calls itself more than {level} times, the function will be
   *        stopped.
   * @return the field
   */
  private static final Optional<Field> getFieldByName(String fieldName, Class<?> clazz, int level) {

    if (clazz == null || level < 1) {
      return Optional.empty();
    }

    try {
      return Optional.ofNullable(clazz.getDeclaredField(fieldName));
    } catch (NoSuchFieldException | SecurityException e) {
      return getFieldByName(fieldName, clazz.getSuperclass(), --level);
    }
  }

  private static final <T> Optional<Method> getMethodByName(T model, String methodName) {
    Method[] methods = model.getClass().getMethods();
    return Stream.of(methods).filter(x -> x.getName().equals(methodName)).findFirst();
  }

  public static final void setProperty(Object obj, String fieldName, String value)
      throws IllegalAccessException {

    Optional<Field> optField = getFieldByName(fieldName, obj.getClass(), 3);
    if (!optField.isPresent()) {
      return;
    }

    Field field = optField.get();
    // allow access private variable
    field.setAccessible(true);
    field.set(obj, cast(field.getType(), value));
  }

  public static final <T> void invokeMethod(T obj, String methodName, String... paramValue)
      throws IllegalAccessException, InvocationTargetException {
    Optional<Method> optMethod = getMethodByName(obj, methodName);

    if (!optMethod.isPresent()) {
      return;
    }
    Method method = optMethod.get();
    // allow access private method
    method.setAccessible(true);

    Class<?>[] parameterTypes = method.getParameterTypes();
    Object[] values = new Object[parameterTypes.length];
    int paramTypesLength = parameterTypes.length;

    for (int i = 0; i < paramTypesLength; i++) {
      values[i] = cast(parameterTypes[i], paramValue[i]);
    }
    method.invoke(obj, values);
  }

  public static <T> Object cast(T clazz, String value) {

    if (clazz.equals(Integer.class)) {
      return Integer.valueOf(value);
    }
    // Double
    if (clazz.equals(Double.class)) {
      return Double.valueOf(value);
    }
    // Float
    if (clazz.equals(Float.class)) {
      return Float.valueOf(value);
    }
    // Long
    if (clazz.equals(Long.class)) {
      return Long.valueOf(value);
    }
    if (clazz.equals(String.class)) {
      return String.valueOf(value);
    }
    throw new IllegalArgumentException("Invalid argument, the value cannot parse to " + clazz);

  }

  public static void main(String[] args) {
    TblHBatlog log = new TblHBatlog();
    try {
      invokeMethod(log, "setBatSq", "10");
    } catch (IllegalAccessException | InvocationTargetException e) {
      e.printStackTrace();
    }
  }
}
