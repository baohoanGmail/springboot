
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;

public class CommonUtils {

  private CommonUtils() {}

  /**
   * Compare two fields by order index
   * 
   * @param orderFields list of fields to be compared
   * @return
   */
  private static final Comparator<FieldError> compareOrderFields(List<String> orderFields) {

    // Your fields, ordered in the way they appear in the form
    return new Comparator<FieldError>() {
      @Override
      public int compare(FieldError fe1, FieldError fe2) {

        String field1 = fe1.getField();
        String field2 = fe2.getField();
        int field1Index = orderFields.indexOf(field1);
        int field2Index = orderFields.indexOf(field2);

        return NumberUtils.compare(field1Index, field2Index);
      }
    };
  }


  /**
   * Collecting the error messages from BindingResult object
   * 
   * @param bindingResult the result after form submitted
   * @return a LIST contains error messages
   */
  public static final List<String> collectErrorMessages(BindingResult bindingResult) {

    OrderFieldValidated validatorOrder =
        bindingResult.getTarget().getClass().getAnnotation(OrderFieldValidated.class);

    List<String> errors = null;
    Stream<FieldError> errorStream = bindingResult.getFieldErrors().stream();

    if (validatorOrder == null) {
      // Sorted without condition
      errors = errorStream.map(FieldError::getDefaultMessage).sorted().collect(Collectors.toList());
    } else {
      List<String> orders = Arrays.asList(validatorOrder.order());
      errors = errorStream.sorted(compareOrderFields(orders)).map(FieldError::getDefaultMessage)
          .collect(Collectors.toList());
    }
    // Get global errors
    List<String> globalErrors = bindingResult.getGlobalErrors().stream()
        .map(ObjectError::getDefaultMessage).collect(Collectors.toList());
    if (!CollectionUtils.isEmpty(globalErrors)) {
      errors.addAll(globalErrors);
    }
    return errors != null ? errors : Collections.emptyList();
  }

  /**
   * Collecting the error messages from BindingResult object
   * 
   * @param bindingResult the result after form submitted
   * @param isBreakLine if true will check each of error and find digit # to separate it
   * 
   * @return a LIST contains error messages
   */

  public static final List<String> collectErrorMessages(BindingResult bindingResult,
      boolean isBreakLine) {

    List<String> errors = collectErrorMessages(bindingResult);
    // return error without separate
    if (!isBreakLine) {
      return errors;
    }

    List<String> returnError = new ArrayList<>();
    errors.forEach(error -> {
      if (error.contains(Const.BREAK_LINE)) {
        returnError.addAll(Arrays.asList(error.split(Const.BREAK_LINE)));
      } else {
        returnError.add(error);
      }
    });
    return returnError;

  }

  /**
   * Check input keys exist in the map
   * 
   * @param map
   * @param keys
   * @return
   */
  public static final boolean isExistAllKeys(Map<String, Object> map, String... keys) {

    if (keys == null || map == null || map.isEmpty()) {
      return false;
    }

    for (int i = 0; i < keys.length; i++) {
      if (!map.containsKey(keys[i])) {
        return false;
      }
    }
    return true;
  }

  /**
   * Get error Messages from map by key ERROR_MESSAGES_ATTRIBUTE
   * 
   * @param map
   * @return
   */
  @SuppressWarnings("unchecked")
  public static List<String> getErrorMessages(Map<String, Object> map) {
    Object value = map.get(Const.ERROR_MESSAGES_ATTRIBUTE);
    return (value != null) ? (List<String>) value : Collections.emptyList();
  }

  /**
   * Initial a SET<String> from array characters
   * 
   * @param value array characters
   * @return set contains those characters
   */
  public static Set<String> asHashSet(String... value) {
    return new HashSet<>(Arrays.asList(value));
  }

  /**
   * Separate IP address and mask number from a IP Source
   * 
   * @param ipSource input an valid IP eg: 123.123.123.123/30
   * @return {@link Map} with 2 elements. <br/>
   *         [ip -> 123.123.123.123] <br/>
   *         [maskAmt -> 30]
   */
  public static Map<String, String> separateIpAddress(String ipSource) {

    Map<String, String> ipaddressMap = new HashMap<>();

    if (ipSource != null && ipSource.length() > 1) {
      String[] ipSourceList = ipSource.split("/");
      ipaddressMap.put(Const.IP_ADDRESS, StringUtils.trim(ipSourceList[0]));
      ipaddressMap.put(Const.MASK_ATM, StringUtils.trim(ipSourceList[1]));
    }
    return ipaddressMap;
  }

  /**
   * Get parameters of the request
   * 
   * @param httpServletRequest HttpServletRequest
   * @return parameters map
   */
  public static Map<String, String> getRequestParameterMap(HttpServletRequest httpServletRequest) {

    Map<String, String[]> params = httpServletRequest.getParameterMap();
    if (params.isEmpty()) {
      return new HashMap<>();
    }

    Map<String, String> retMap = new HashMap<>();
    params.forEach((key, value) -> retMap.put(key, String.join(", ", value)));

    return retMap;
  }


  /**
   * Finding the value of ROLE_TCD enumerable by id
   * 
   * @param id
   * @return
   */
  public static String findRoleTcdValueById(int id) {
    return Stream.of(ROLE_TCD.values()).filter(x -> (x.id() == id)).findFirst().map(ROLE_TCD::value)
        .orElse(StringUtils.EMPTY);
  }

  /**
   * Get IP address from request
   * 
   * @param request HttpServletRequest
   * @return IP Address
   */
  public static String getIPAdress(HttpServletRequest request) {
    String ip = request.getHeader("X-FORWARDED-FOR");
    if (StringUtils.isEmpty(ip)) {
      ip = request.getRemoteAddr();
    }

    return ip;
  }

  /**
   * Get user agent from request
   * 
   * @param request HttpServletRequest
   * @return User Agent
   */
  public static String getUserAgent(HttpServletRequest request) {
    return request.getHeader("User-Agent");
  }

  /**
   * Finding the value of FBPM enumerable by id
   * 
   * @param id
   * @return
   */
  public static String findFBPMValueById(String id) {
    return Stream.of(AuthenFunctionCode.FBPM.values()).filter(x -> (StringUtils.equals(x.id(), id)))
        .findFirst().map(AuthenFunctionCode.FBPM::value).orElse(StringUtils.EMPTY);
  }

  /**
   * Get current domain
   * 
   * @param request
   * @return
   */
  public static String getCurrentDomain(HttpServletRequest request) {

    StringBuilder sb = new StringBuilder();
    sb.append(request.getScheme() + "://");
    sb.append(request.getServerName());

    return sb.toString();
  }

  /**
   * Finding the value of TRN_STS_CD enumerable by id
   * 
   * @param id
   * @return
   */
  public static String findTrnStsCdValueById(int id) {
    return Stream.of(TRN_STS_CD.values()).filter(x -> (x.id() == id)).findFirst()
        .map(TRN_STS_CD::value).orElse(StringUtils.EMPTY);
  }

  public static String[] asArray(List<String> values) {
    return values.toArray(new String[values.size()]);
  }

  public static final String addHttps(String url) {
    if (url == null || url.length() == 0) {
      return Const.HTTPS_URL;
    }

    if (url.startsWith(Const.HTTPS_URL)) {
      return url;
    }

    if (url.startsWith(Const.HTTP)) {
      return url.replace(Const.HTTP, Const.HTTPS_URL);
    }
    return Const.HTTPS_URL + url;
  }

}
