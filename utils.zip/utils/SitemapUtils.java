
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

public class SitemapUtils {

  private SitemapUtils() {}

  public static void disableSitemapTags(XXXXTag parent, String jobType) {
    if (CollectionUtils.isNotEmpty(parent.getChilds())) {
      XXXTag child = null;
      for (int index = 0; index < parent.getChilds().size(); ++index) {
        child = parent.getChilds().get(index);
        disableSitemapTags(child, jobType);
        if (!child.isActiveByTargetJob()) {
          index = parent.getChilds().remove(child) ? (index - 1) : index;
        }
      }
    }
    // Disable tags whose targetJobs's property doesn't contain current jobType
    if (jobTypeNotExists(parent, jobType)) {
      parent.setActiveByTargetJob(false);
    }
  }

  public static boolean jobTypeNotExists(XXXXTag tag, String jobType) {
    // only check the tags under DISEASE_TAG_PATH path
    if (StringUtils.isNotEmpty(tag.getPath())
        && tag.getPath().contains(Constants.DISEASE_TAG_PATH)) {
      return tag.getTargetJobs().stream().noneMatch(x -> x.contains(jobType));
    }
    return false;
  }

}
