
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.InputSource;
import org.xml.sax.XMLFilter;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import com.adobe.dam.print.ids.StringConstants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.SearchResult;
import com.sun.xml.bind.marshaller.CharacterEscapeHandler;

/**
 * The Class XMLParserUtils.
 */
public class XMLParserUtils {

  /**
   * Class logger
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(XMLParserUtils.class);

  private XMLParserUtils() {}

  /**
   * Gets the xsl file.
   *
   * @param xmlTemplateType the type template (pi, guide, rmpIndex, rmpDetail).
   * @param pageSection the type
   * @return the xsl file
   */
  public static String getXslFileByType(String xmlTemplateType, String pageSection) {

    String pathPrefix = String.format("/xml-templates/%s", xmlTemplateType);
    switch (xmlTemplateType) {
      case Constants.XLSL_PI:
        if (Constants.HTML_HEADER.equals(pageSection)) {
          return pathPrefix + "/header.xsl";
        } else if (Constants.HTML_NAVI.equals(pageSection)) {
          return pathPrefix + "/navi.xsl";
        } else if (Constants.HTML_MAIN.equals(pageSection)) {
          return pathPrefix + "/main.xsl";
        }
        break;
      case Constants.XLSL_GUIDE:
        if (Constants.HTML_HEADER.equals(pageSection)) {
          return pathPrefix + "/top.xsl";
        } else if (Constants.HTML_NAVI.equals(pageSection)) {
          return pathPrefix + "/left.xsl";
        } else if (Constants.HTML_MAIN.equals(pageSection)) {
          return pathPrefix + "/main.xsl";
        }
        break;
      case Constants.XLSL_RMP_DETAIL:
      case Constants.XLSL_RMP_INDEX:
        if (Constants.HTML_HEADER.equals(pageSection)) {
          return pathPrefix + "/rmp_header.xsl";
        } else if (Constants.HTML_LEFT.equals(pageSection)) {
          return pathPrefix + "/rmp_left.xsl";
        } else if (Constants.HTML_RIGHT.equals(pageSection)) {
          return pathPrefix + "/rmp_right.xsl";
        } else if (Constants.HTML_INDEX.equals(pageSection)) {
          return pathPrefix + "/rmp_html.xsl";
        } else if (Constants.HTML_POPUP.equals(pageSection)) {
          return pathPrefix + "/rmp_popup.xsl";
        }
        break;
      default:
    }
    return StringUtils.EMPTY;
  }

  /**
   * Parsing XML Object to XML.
   *
   * @param <T> the generic type
   * @param model the model
   * @param writer the writer
   */
  public static <T> void marshal(T model, PrintWriter writer) {
    if (Objects.isNull(model) || Objects.isNull(writer)) {
      LOGGER.warn("The input are empty, could not generate XML file");
      return;
    }

    try {
      JAXBContext context = null;
      final ClassLoader oldLoader = Thread.currentThread().getContextClassLoader();
      try {
        Thread.currentThread()
            .setContextClassLoader(javax.xml.bind.JAXBContext.class.getClassLoader());
        context = JAXBContext.newInstance(model.getClass());
      } finally {
        Thread.currentThread().setContextClassLoader(oldLoader);
      }
      Marshaller m = context.createMarshaller();
      m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
      m.setProperty("com.sun.xml.bind.marshaller.CharacterEscapeHandler",
          new CharacterEscapeHandler() {
            @Override
            public void escape(char[] ch, int start, int length, boolean isAttVal, Writer writer)
                throws IOException {
              writer.write(ch, start, length);
            }
          });
      m.marshal(model, writer);
    } catch (Exception e) {
      LOGGER.error("Error while parsing Object to XML {}", e.getMessage());
    }
  }

  /**
   * Parsing XML to XML Object.
   *
   * @param <T> the generic type
   * @param model the model
   * @param writer the writer
   */
  @SuppressWarnings({"unchecked", "javadoc"})
  public static <T> T unmarshal(InputStream is, Class<?> clazz) throws JAXBException {
    if (Objects.isNull(is)) {
      LOGGER.warn("There is no input data");
      return null;
    }
    T model = null;
    JAXBContext context = null;
    final ClassLoader oldLoader = Thread.currentThread().getContextClassLoader();
    try {
      Thread.currentThread()
          .setContextClassLoader(javax.xml.bind.JAXBContext.class.getClassLoader());
      context = JAXBContext.newInstance(clazz);
    } finally {
      Thread.currentThread().setContextClassLoader(oldLoader);
    }
    Unmarshaller um = context.createUnmarshaller();
    model = (T) um.unmarshal(is);
    return model;
  }

  /**
   * normalize showId.
   * 
   * @param showId unique id in XSL template
   * @return showId normalized
   * 
   *         <pre>
   * Example: 
   * normalizeShowId(2) -> 2; 
   * normalizeShowId(2.1) -> 2; 
   * normalizeShowId(2.1.4) -> 2
   *         </pre>
   */
  private static String normalizeShowId(String showId) {
    if (StringUtils.isBlank(showId)) {
      return "1";
    }
    int indexOfDot = StringUtils.indexOf(showId, '.');
    return (indexOfDot > 0) ? StringUtils.substring(showId, 0, indexOfDot) : showId;
  }

  private static boolean checkValidType(String filename, String... extensions) {
    if (StringUtils.isBlank(filename)) {
      return false;
    }
    int lastIndexOfDot = filename.lastIndexOf('.');
    String ext = (lastIndexOfDot > 0) ? filename.substring(lastIndexOfDot + 1) : "n/a";
    return Arrays.asList(extensions).contains(ext);
  }

  private static Transformer buildTransformer(String filePath, ResourceResolver resolver) {
    Transformer transformer = null;
    try (InputStream xslTemplate = CommonUtils.readFile(filePath, resolver)) {
      TransformerFactory tFactory = TransformerFactory.newInstance();
      tFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
      if (xslTemplate == null) {
        LOGGER.info("Cannot read XSL template {}", filePath);
        return null;
      }
      transformer = tFactory.newTransformer(new StreamSource(xslTemplate));
      transformer.setOutputProperty(OutputKeys.INDENT, "yes");

    } catch (TransformerConfigurationException | IOException e) {
      LOGGER.error("Cannot create transformer {}", e.getMessage());
    }
    return transformer;
  }

  /**
   * Transform XML to HTML using XSL for Package Insert & Guide pages
   *
   * @param request the request info from client
   * @param resolver the resource resolver
   * @param pageSection the page's section (top, left, right, main, navigation)
   * @param map the map contains values from the dialog input
   * @param deviceTypeId the id of device type PC or Mobile
   * @return String HTML generated by Transform XML to HTML using XSL
   */
  public static String xml2html(SlingHttpServletRequest request, ResourceResolver resolver,
      String pageSection, Map<String, String> map, String deviceTypeId) {

    String xmlFilePath = map.get(Constants.XML_FILE_PATH);
    String xmlType = map.get(Constants.XML_TYPE);
    LOGGER.info("Start converting XML to HTML... {} - {}", xmlType, xmlFilePath);

    Optional<File> sgmlTempFile = Optional.empty();
    try (InputStream inputStream = CommonUtils.readFile(xmlFilePath, resolver)) {
      if (checkValidType(xmlFilePath, "sgm", "sgml")) {
        LOGGER.info("Staring convert sgml file!");
        // The SGML file only use for package insert type
        sgmlTempFile = new PackageInsertFilter().smgl2xml(inputStream);
      }
      String showId = StringUtils.trimToEmpty(request.getParameter(Constants.SHOW_ID_PARAM));
      String templatePath = XMLParserUtils.getXslFileByType(xmlType, pageSection);
      LOGGER.info("[xml2html] Start building transformer...");
      Transformer transformer = buildTransformer(templatePath, resolver);
      if (transformer == null) {
        LOGGER.info("[xml2html] Stopping convert because of failure to build transformer ...");
        return StringUtils.EMPTY;
      }

      String assetsPath = StringUtils.EMPTY;
      Optional<String> assetsPathOptional = Optional.ofNullable(map.get(Constants.ASSETS_PATH));
      if (assetsPathOptional.isPresent()) {
        assetsPath = LinkUtils.getLinkWithEndSlash(assetsPathOptional.get());
      }
      LOGGER.info("Assets path {}", assetsPath);

      String currentPage = LinkUtils.getProperURL(map.get(Constants.CURRENT_PAGE), resolver);
      transformer.setParameter(Constants.XML_FILE_PATH_PARAM, xmlFilePath);
      transformer.setParameter(Constants.XSL_FILE_PATH_PARAM, templatePath);
      transformer.setParameter(Constants.IMAGE_PATH_PARAM, assetsPath);
      transformer.setParameter(Constants.DIALOG_ID, map.get(Constants.DIALOG_ID));
      transformer.setParameter(Constants.ID_TYPE_PARAM, deviceTypeId);
      transformer.setParameter(Constants.CURRENT_PAGE, currentPage);
      transformer.setParameter(Constants.SHOW_ID_PARAM, normalizeShowId(showId));
      StringWriter text = new StringWriter();
      if (sgmlTempFile.isPresent()) {
        LOGGER.info("Start converting SGML to HTML");
        transformer.transform(new StreamSource(sgmlTempFile.get()), new StreamResult(text));
        // Deleting XML file stored in temporary directory
        CommonUtils.deleteIfExists(sgmlTempFile.get());
      } else {
        transformer.transform(new StreamSource(inputStream), new StreamResult(text));
      }
      return text.toString();
    } catch (IOException | TransformerException e) {
      LOGGER.error("[xm2html][Exception] {}", e.getMessage());
    }
    return StringUtils.EMPTY;
  }


  /**
   * Transform XML to HTML using XSL for RMP page
   *
   * @param request the request info from client
   * @param resolver the resource resolver
   * @param pageSection the page's section (top, left, right, main, navigation)
   * @param map the map contains values from the dialog input
   * @param deviceTypeId the id of device type PC or Mobile
   * @return String HTML generated by Transform XML to HTML using XSL
   */
  public static String rmp2html(ResourceResolver resolver, String pageSection,
      Map<String, String> map, String deviceTypeId) {

    String xmlFilePath = map.get(Constants.XML_FILE_PATH);
    String xmlType = map.get(Constants.XML_TYPE);
    LOGGER.info("Start converting XML(RMP) to HTML... {} - {}", xmlType, xmlFilePath);

    try (InputStream xmlFile = CommonUtils.readFile(xmlFilePath, resolver)) {

      String templatePath = XMLParserUtils.getXslFileByType(xmlType, pageSection);
      LOGGER.info("[rmp2html] Start building transformer...");
      Transformer transformer = buildTransformer(templatePath, resolver);
      if (transformer == null) {
        LOGGER.info("[rmp2html] Stopping convert because of failure to build transformer ...");
        return StringUtils.EMPTY;
      }
      if (Constants.HTML_INDEX.equalsIgnoreCase(pageSection)) {
        transformer.setParameter(Constants.XML_RMP_DETAIL_PATH,
            map.get(Constants.XML_RMP_DETAIL_PATH));
      }
      StringWriter writer = new StringWriter();
      if (StringUtils.isNotBlank(map.get(Constants.LINK_GROUP_ID))) {
        transformer.setParameter(Constants.LINK_GROUP_ID,
            Integer.parseInt(map.get(Constants.LINK_GROUP_ID)));
      }
      transformer.setParameter(Constants.ID_TYPE_PARAM, deviceTypeId);

      // Executing RMP filter if xslType is XML-detail-page and section is RIGHT page.
      if (Constants.HTML_RIGHT.equalsIgnoreCase(pageSection)
          && Constants.XLSL_RMP_DETAIL.equalsIgnoreCase(xmlType)) {
        XMLReader reader = XMLReaderFactory.createXMLReader();
        reader.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        XMLFilter rmpFilter = new RMPFilter(reader, resolver, map);
        transformer.transform(new SAXSource(rmpFilter, new InputSource(xmlFile)),
            new StreamResult(writer));
      } else {
        transformer.transform(new StreamSource(xmlFile), new StreamResult(writer));
      }
      return writer.toString();
    } catch (Exception e) {
      LOGGER.error("[rmp2html][exception]" + e.getMessage());
      return StringUtils.EMPTY;
    }
  }

  /**
   * Copy files to TEMP folder.
   *
   * @param xslPath the XSL path get from the dialog
   * @param classFromBundle the class from bundle
   * @return the file read from XSLPath
   */
  public static File getTemplateByType(String xslPath, Class<?> classFromBundle) {
    try {
      BundleContext context = FrameworkUtil.getBundle(classFromBundle).getBundleContext();
      Bundle bundle = context.getBundle();
      URL url = bundle.getEntry(xslPath);
      File xslFile = new File(FileUtils.getTempDirectory().getPath() + xslPath);
      FileUtils.copyInputStreamToFile(url.openStream(), xslFile);
      return xslFile;
    } catch (IOException e) {
      LOGGER.error("[ERROR]" + e.getMessage());
      return null;
    }
  }

  /**
   * Gets the resource node from AEM by generateId.
   *
   * @param resolver the resolver
   * @param pagePath only find the element under input path.
   * @param generateId the generate id
   * @return the resource by generate id
   * @throws RepositoryException the repository exception
   */
  public static Resource getResourceByGenerateId(ResourceResolver resolver, String pagePath,
      String generateId) throws RepositoryException {

    Resource resource = null;
    try {
      QueryBuilder builder = resolver.adaptTo(QueryBuilder.class);

      if (builder == null || StringUtils.isBlank(generateId)) {
        LOGGER.error(Constants.EXCEPTION, "QueryBuilder is empty.");
        return resource;
      }

      Session session = resolver.adaptTo(Session.class);
      Map<String, String> map = new HashMap<>();
      String relPath = StringUtils.defaultIfBlank(pagePath, Constants.XXX);
      LOGGER.info("The Query excuted under {}", relPath);

      map.put(Constants.PATH, relPath);
      map.put(Constants.TYPE, StringConstants.NT_UNSTRUCTURED);

      map.put("property", "generateId");
      map.put("property.value", generateId);

      Query query = builder.createQuery(PredicateGroup.create(map), session);
      SearchResult result = query.getResult();

      if (!result.getHits().isEmpty()) {
        resource = result.getHits().get(0).getResource();
      }

      return resource;
    } catch (RepositoryException e) {
      LOGGER.error(Constants.EXCEPTION, e);
      return resource;
    }
  }

  /**
   * Count the resource node from AEM by generateId.
   *
   * @param resolver the resolver
   * @param generateId the generate id
   * @return the resource by generate id
   */
  public static int countResourceByGenerateId(ResourceResolver resolver, String generateId) {

    QueryBuilder builder = resolver.adaptTo(QueryBuilder.class);

    if (builder == null || StringUtils.isBlank(generateId)) {
      LOGGER.error(Constants.EXCEPTION, "QueryBuilder is empty.");
      return -1;
    }

    Session session = resolver.adaptTo(Session.class);
    Map<String, String> map = new HashMap<>();

    map.put(Constants.PATH, Constants.XXX);
    map.put(Constants.TYPE, StringConstants.NT_UNSTRUCTURED);

    map.put("property", "generateId");
    map.put("property.value", generateId);

    Query query = builder.createQuery(PredicateGroup.create(map), session);
    SearchResult result = query.getResult();

    return result.getHits().size();
  }

  /**
   * Get previous page path from request
   * 
   * @param request
   * @return the path of previous page.
   */
  public static String getPrevPathFromRequest(final SlingHttpServletRequest request) {
    try {
      String previousPageURL = request.getHeader("referer");
      URI uri = new URI(previousPageURL);
      LOGGER.info("The URL of previous page {}", previousPageURL);
      return AuthenticationUtils.correctJCRPath(uri.getPath());
    } catch (URISyntaxException e) {
      LOGGER.error("[URISyntaxException] Initlization failed {}", e.getMessage());
      return StringUtils.EMPTY;
    }
  }
}
